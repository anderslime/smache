============================================================
SMache - Smart Caching with automatic invalidation
============================================================

For documentation go to `the GitHub repository <http://github.com/anderslime/smache>`_
