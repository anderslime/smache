from collections import namedtuple as struct

CacheResult = struct("CacheResult", ["value"])
